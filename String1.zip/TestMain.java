package com.cognizant.testmain;

import java.util.Scanner;

import com.cognizant.training.*;

public class TestMain {
	
	public static void main(String args[]){
		Employee emp = new Employee();
		acceptEmployeeDetails(emp);
		displayEmployeeDetails(emp);
	}
	private static void displayEmployeeDetails(Employee emp){
		System.out.println("Employee Id"+emp.getEmployeeId());
		System.out.println("Employee Name"+emp.getEmployeeName());
		System.out.println("Employee Address1"+emp.getAddress().getAddress1());
		System.out.println("Employee Address2"+emp.getAddress().getAddress2());
		System.out.println("Employee City"+emp.getAddress().getCity());
		System.out.println("Employee Pincode"+emp.getAddress().getPincode());
		
	}
	private static void acceptEmployeeDetails(Employee emp){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee ID");
		String empId = sc.nextLine();
		emp.setEmployeeId(empId);
		System.out.println("Enter Employee Name");
		String empName = sc.nextLine();
		emp.setEmployeeName(empName);
		Address address = new Address();
		System.out.println("Enter the employee Address1");
		String address1 = sc.nextLine();
		address.setAddress1(address1);
		System.out.println("Enter the employee Address2");
		String address2 = sc.nextLine();
		address.setAddress2(address2);
		System.out.println("Enter the employee City");
		String city = sc.nextLine();
		address.setCity(city);
		System.out.println("Enter the employee Pincode22");
		int pincode = sc.nextInt();
		address.setPincode(pincode);
		emp.setAddress(address);
	}

}

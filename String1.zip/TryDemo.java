
public class TryDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10, b=2,c;
		try{
			c = 10/2;
		}
		finally{
			System.out.println("Finally");
		}
	}

}

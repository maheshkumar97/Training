package com.springpackage;

import java.util.Set;

public class SpringSet {

	private Set<Employee> set;

	public void setSet(Set<Employee> set) {
		this.set = set;
	}

	public Set getSet() {
		return set;
	}

	@Override
	public String toString() {
		return "SpringList list=" + set + "\n";
	}

}

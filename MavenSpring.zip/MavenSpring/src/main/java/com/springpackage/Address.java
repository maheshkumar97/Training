package com.springpackage;

public class Address {

	private int number;
	private String hname;
	
	
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getHname() {
		return hname;
	}
	public void setHname(String hname) {
		this.hname = hname;
	}
	
	@Override
	public String toString() {
		return "Address [number=" + number + ", hname=" + hname + "]";
	}
}

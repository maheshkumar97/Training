package com.springpackage;

public class Employee {

	private int id;
	private Address addr;
	
	public Employee(Address addr) {
		super();
		this.addr = addr;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", addr=" + addr + "]";
	}
	

}

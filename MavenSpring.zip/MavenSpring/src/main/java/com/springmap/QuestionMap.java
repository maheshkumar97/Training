package com.springmap;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class QuestionMap {

	private int id;
	private String name;
	private Map<String, String> answers;

	public QuestionMap() {

	}

	public QuestionMap(int id, String name, Map<String, String> answers) {
		this.id = id;
		this.name = name;
		this.answers = answers;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<String, String> getAnswers() {
		return answers;
	}

	public void setAnswers(Map<String, String> answers) {
		this.answers = answers;
	}

	@Override
	public String toString() {
		return "QuestionMap [id=" + id + ", name=" + name + ", answers=" + answers + "]";
	}

	public void displayInfo() {
		System.out.println("Question id " + id);
		System.out.println("Question name " + name);
		System.out.println("Answers....");

		Set<Map.Entry<String, String>> set = answers.entrySet();

		Iterator<Entry<String, String>> itr = set.iterator();
		while (itr.hasNext()) {
			Entry<String, String> entry = itr.next();
			System.out.println("Answer " + entry.getKey() + " Posted By " + entry.getValue());
		}
	}

}

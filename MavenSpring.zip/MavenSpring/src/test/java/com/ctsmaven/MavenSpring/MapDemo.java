package com.ctsmaven.MavenSpring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springmap.QuestionMap;

public class MapDemo {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("configmap.xml");
		QuestionMap que = (QuestionMap) context.getBean("firstBean");

		que.displayInfo();

	}

}

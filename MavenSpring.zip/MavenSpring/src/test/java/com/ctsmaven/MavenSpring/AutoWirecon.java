package com.ctsmaven.MavenSpring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.springpackage.Employee;
import com.springpackage.Employee1;

public class AutoWirecon {

	public static void main(String[] args) {
		Resource r=new ClassPathResource("AutoWire.xml");
		BeanFactory b=new XmlBeanFactory(r);
		Employee obj = (Employee) b.getBean("employ");
		System.out.println(obj);
		
		Employee obj1 = (Employee) b.getBean("employ1");
		System.out.println(obj1);
		
		Employee1 obj2 = (Employee1) b.getBean("employ2");
		System.out.println(obj2);
	}

}

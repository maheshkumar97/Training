package com.ctsmaven.MavenSpring;

import java.util.HashSet;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springpackage.Employee;
import com.springpackage.SpringSet;

public class SetDemo {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("configure.xml");
		SpringSet set = (SpringSet) context.getBean("set");
		Set<Employee> obj = (HashSet<Employee>) set.getSet();
		for (Employee emp : obj) {
			System.out.println(emp);
		}

	}

}

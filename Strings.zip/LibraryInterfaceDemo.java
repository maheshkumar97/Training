
public class LibraryInterfaceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		KidUsers kid1 = new KidUsers();
		kid1.age = 10;
		kid1.bookType = "kids";
		kid1.registerAccount();
		kid1.requestBook();
		KidUsers kid2 = new KidUsers();
		kid2.age = 20;
		kid2.bookType = "Fiction";
		kid2.registerAccount();
		kid2.requestBook();
		AdultUser adult1 = new AdultUser();
		adult1.age = 25;
		adult1.bookType = "Fiction";
		adult1.registerAccount();
		adult1.requestBook();
		AdultUser adult2 = new AdultUser();
		adult2.age = 5;
		adult2.bookType = "Kids";
		adult2.registerAccount();
		adult2.requestBook();
	}

}

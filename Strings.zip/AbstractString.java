
public abstract class AbstractString {
	String str;
	public abstract void display ( ) ;

}

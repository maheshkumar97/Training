
public class UpperString  {
	{
	}
}

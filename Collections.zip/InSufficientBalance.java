package com.Exception;

//@SuppressWarnings("serial")
public class InSufficientBalance extends RuntimeException {

	String message;
	public InSufficientBalance(String message) {
		
			super();
			this.message = message;
	}
		public String getMessage(){
			return message;
		}
}

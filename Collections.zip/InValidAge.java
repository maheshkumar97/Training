package com.Exception;
import java.lang.RuntimeException;
public class InValidAge extends RuntimeException{
	String message;
	public InValidAge(String message) {
		super();
		this.message = message;
	}
	public String getMessage(){
		return message;
	}
}

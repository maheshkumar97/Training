package com.Exception;

public class SimpleException {
	
	int age;
	public SimpleException(int age) {
		this.age = age;
	}
	public void validateAge(){
		/*if(age<18){
			throw new InValidAge("Invalid Age");
		}
		else{
			System.out.println("Age is Acceptble");
		}*/
		try{
			if(age<18){
				throw new InValidAge("Invalid Age");
			}
			else
				System.out.println("Valid Age");
		}catch(InValidAge ex){
			System.out.println(ex);
			System.out.println(ex.getMessage());
			System.out.println(ex);
		}
	}

	public static void main(String[] args) {
		SimpleException sim = new SimpleException(2);
		sim.validateAge();
		SimpleException sim1 = new SimpleException(21);
		sim1.validateAge();
	}

}

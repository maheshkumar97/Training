package com.handler;

import java.util.ArrayList;
import java.util.List;

import com.dao.BookDao;

import com.usertype.Book;

public class BookDaoIml implements BookDao {
	
	List<Book>  li = new ArrayList<Book>();
	
	{
	li.add(new Book(12332,"Java"));
	li.add(new Book(12231,"Advance Java"));
	li.add(new Book(34233,"Intro to Python"));
	li.add(new Book(23443,"JavaScript"));
	}
	
	@Override
	public List<Book> getList() {
		return li;
	}

	@Override
	public Book getBook(int isbn) {
		Book bk = null;
		for(int i=0;i<li.size();i++){
		bk = getList().get(i);
		if(bk.getIsbn()==isbn)
			break;
		else
			bk = null;
		}
		return bk;
}

	@Override
	public void save(int isbn,String name) {
		Book b = new Book(isbn,name);
		li.add(b);
		//li.add(new Book(b.getIsbn(),b.getName()));
	}

	@Override
	public void delete(int isbn) {
		
		Book bk = null;
		for(int i=0;i<li.size();i++){
		bk = getList().get(i);
		if(bk.getIsbn()==isbn){
			li.remove(bk);
			break;
		}
		}
	}
}

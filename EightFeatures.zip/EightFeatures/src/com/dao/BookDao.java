package com.dao;

import java.util.List;

import com.usertype.Book;

public interface BookDao {
	
	List<Book> getList();
	Book getBook(int isbn);
	void save(int isbn, String named);
	void delete(int isbn);

}

package com.java8;

import java.time.LocalTime;

public class TestDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalTime a = LocalTime.now();
		System.out.println(a);

	}

}

package com.java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamEx {

	public static void main(String[] args) {
		
		List<String> list = new ArrayList();
		String[] a ={"Mahesh", "Brenden", "Anirud"};
		
		List<String> list1 = Arrays.asList(a);
		
		list.add("Ajmeer");
		list.add("John");
		list.add("Sehwag");
		list.add("Aditya");
		list.add("Steven");
		
		list.addAll(list1);
		//Use of Stream to count words with less than 6 letters
		long count = list.stream().filter(str->str.length()<6).count();
		System.out.println("There are "+count+" strings with size less than 6");
		
		//Concatinating to lists 
		Stream<String> str1 = Stream.concat(list1.stream(), list.stream());
		
		System.out.println("----------------------------");
		str1.forEach(str->System.out.println(str));
		//Converting Stream data to list data
		System.out.println("----------------------------");
		List list2 = list.stream().collect(Collectors.toList());
		System.out.println(list2);
		System.out.println("----------------------------");
		list.stream().sorted().forEach(str->System.out.println(str));
		System.out.println("----------------------------");
		
		list.stream().forEach(str->System.out.println(str.toUpperCase()));
		list.stream();
		
	}

}

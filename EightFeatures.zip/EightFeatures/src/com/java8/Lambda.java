package com.java8;

@FunctionalInterface
interface TestPi<T>{
	/*
	 * Functional Interface 
	 * It has only one method
	 */
	/*double getPi();*/
	/*double getSum(int a, int b);*/
	
	/*int getFact(int a);*/
	
	T commonMethod(T t);
	
}


public class Lambda {

	public static void main(String[] args) {
		
		/*
		 * Lambda Function helps to reduce the code to function interface method implementation.
		 * Using the lambda function we implement it in a single statement
		 */
		
		/* For No Parameters 
		 TestPi p=()->3.14;
		 * /
		
		/* For Parameters
		int x=10;
		int y=10;
		TestPi p = (a,b)-> x+y;
		System.out.println(p+" \nP value is "+p.getSum(x,y));
		*/
		
	
		/*	For single parameter
			 	TestPi fact=(a)->{
				int f=1;
				for(int i=1;i<=a;i++)
					f=f*i;
				return f;
				};
			System.out.println(fact.getFact(5));
		}
		*/
		TestPi<Integer> fact=(a)->{
			int f=1;
			for(int i=1;i<=a;i++)
				f=f*i;
			return f;
			};
		System.out.println(fact.commonMethod(5));
		/*
		 * This is a example of Making a Generic Interface which is used for
		 * Integer, Long, Double, Character, Boolean, Short, Byte, Float, Boolean
		 */
		TestPi<String> reverse=(a)->{
			return a.concat(" Gone");
			};
		System.out.println(reverse.commonMethod("Maheshkumar"));
		
	}
}

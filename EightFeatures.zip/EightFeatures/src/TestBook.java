import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.dao.BookDao;
import com.handler.BookDaoIml;
import com.usertype.Book;

public class TestBook {
	
	public static void main(String[] args) {
		
		BookDao bk = new BookDaoIml();
		
		System.out.println("Printing all Book");
		for(Book b: bk.getList()){
			System.out.println("Book isbn: "+b.getIsbn()+" Book name: "+b.getName());
		}
		
		System.out.println("----------------------------");
		
		System.out.println("Adding Book 12234 C#");
		bk.save(12234,"C#");
		
		System.out.println("----------------------------");
		
		for(Book b: bk.getList()){
			System.out.println("Book isbn: "+b.getIsbn()+" Book name: "+b.getName());
		}
		
		System.out.println("----------------------------");
		System.out.println("Deleting Book 34233");
		bk.delete(34233);
		for(Book b: bk.getList()){
			System.out.println("Book isbn: "+b.getIsbn()+" Book name: "+b.getName());
		}
		
		System.out.println("----------------------------");
		
		System.out.println("Getting a specified book using ISBN=12231");
		System.out.println(bk.getBook(12231));
	}

}

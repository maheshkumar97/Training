package com.collections;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ListDemo {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("NewFile2.xml");
		SpringList list = (SpringList) context.getBean("list");
		ArrayList<Employee> obj = (ArrayList) list.getList();
		for(Employee emp: obj){
			System.out.println(emp);
		}
	}

}

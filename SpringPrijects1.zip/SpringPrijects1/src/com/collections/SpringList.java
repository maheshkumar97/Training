package com.collections;

import java.util.List;

public class SpringList {
	
	private List<Employee> list;

	public void setList(List<Employee> list) {
		this.list = list;
	}
	
	public List getList(){
		return list;
	}
	@Override
	public String toString() {
		return "SpringList list=" + list+"\n";
	}
		
}

package com.bean;

public class Customer {

	private Person person;
	private int cusid;
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	public int getCusid() {
		return cusid;
	}
	public void setCusid(int cusid) {
		this.cusid = cusid;
	}
	@Override
	public String toString() {
		return "Customer [person=" + person + ", cusid=" + cusid + "]";
	}
	
}

package com.bean;

//import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
//import org.springframework.core.io.Resource;

public class TestDemo {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("NewFile.xml");
		
		Customer obj = (Customer) context.getBean("customer");
		Customer obj1 = (Customer) context.getBean("customer1");
		Employee obj2 = (Employee) context.getBean("employee");
		
		System.out.println(context.getClass());
		System.out.println(obj.getCusid()+" "+obj.getPerson());
		
//		System.out.println(context.getClass());
		System.out.println(obj.getCusid()+" "+obj1.getPerson());
		
//		System.out.println(context.getClass());
		System.out.println(obj2.getId()+" "+obj2.getName()+" "+obj2.getAddress());

	}

}

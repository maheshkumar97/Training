package com.dababase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login {

	public boolean compare(String email, String pass) throws SQLException, ClassNotFoundException {
		
		ResultSet resultSet;
		Connection con;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cognizant","root","sql@admin");
		PreparedStatement pst = con.prepareStatement("Select * from login where email = ? and password =?");
		pst.setString(1,email);
		pst.setString(2,pass);
		resultSet = pst.executeQuery();
		
		return resultSet.next();

	}

}

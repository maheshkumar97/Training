package com.dababase;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class simpleConnection {

	public static void main(String[] args) throws SQLException {
		
		Connection con = null;
		ResultSet rs = null;
		Statement stmt = null;
		PreparedStatement ps = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mahesh","root","sql@admin");
			stmt = con.createStatement();
			//String insert = "insert into employee values(64,'John','David',123456789)";
			//String insert = "insert into employee values(94,'John','David',123456789)";
			//String insert1 = "insert into employee values(64,'John','David',123456789)";
			//boolean i = stmt.execute(insert);
			rs = stmt.executeQuery("Select * from employee");
			while(rs.next()){
				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4));
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		finally{
			if(con!=null)
				con.close();
			if(stmt!=null)
				stmt.close();
			if(rs!=null)
				rs.close();
			if(ps!=null)
				ps.close();
		}

	}
}
package com.dababase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TransactionMgm {

	static Scanner sc = new Scanner(System.in);
	static Connection con=null;
	
		void enterData(int n) throws SQLException{
			PreparedStatement pst = con.prepareStatement("insert into Student values(?,?,?)");
				for(int i=0;i<n;i++){
					pst.setInt(1,sc.nextInt());
					pst.setString(2,sc.next());
					pst.setString(3,sc.next());
					pst.executeUpdate();
				}
				if(pst!=null)
					pst.close();
		}
		
		public static void main(String[] args) throws ClassNotFoundException, SQLException {
			
			TransactionMgm ts = new TransactionMgm();
			
			PreparedStatement ps ;
			Statement stmt = null;
			ResultSet rs = null;
			//String st = "create table student(id int, name varchar(20), branch varchar(4))";
			boolean b;
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cognizant","root","sql@admin");
				con.setAutoCommit(false);
				stmt = con.createStatement();
				//b = stmt.execute(st);
				System.out.println("Enter the number of students to enter into DB");
				int n = sc.nextInt();
				if(n>=0){
				ts.enterData(n);
				}
				//stmt.execute("DELETE FROM student WHERE id = 123;");
				con.commit();
				rs = stmt.executeQuery("select * from student");
				int i =1;
				while(rs.next()){
					System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3));
				}
				
			} catch (SQLException e) {
				System.out.println(e);
				//e.printStackTrace();
			}
			try{
				if(con!=null){
					con.rollback();
					System.out.println("RoolBack");
				}
			}catch(SQLException e){
				System.out.println(e);
			}
			
			finally{
				if(con!=null){
					con.close();
					System.out.println("Connection closed");
				}
				if(stmt!=null)
					stmt.close();
				if(rs!=null)
					rs.close();
			}
			
		}
}

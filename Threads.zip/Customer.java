package com.thread;

import com.Exception.InSufficientBalance;

public final class Customer {
	int amount, flag;
	{
		amount = 0;
		flag = 0;
	}

	/*public Customer() {
		// TODO Auto-generated constructor stub
	}*/
	public synchronized void withdraw(int amount){
		System.out.println(Thread.currentThread().getName()+" is going to withdraw "+amount);
		if(flag==0){
			try{
				System.out.println("There is no balance in account.... please wait, till amount deposited");
				wait();
			}catch (InterruptedException e){
				System.out.println(e);				
			}
		}
		try{
			if(this.amount<amount){
				throw new InSufficientBalance(String.format("The account has only %d amount", this.amount));
			}
			else{
				this.amount-=amount;
				System.out.println("Withdrawn Successfull");
				System.out.println("Amount withdraw was :"+amount);
				//return this.amount;
				//Integer
			}
		}catch (InSufficientBalance b){
			System.out.println(b.getMessage());
		}
		/*if(this.amount<amount){
			throw new InSuffiecientBalance(String.format("The account has only %d amount", this.amount));//InSuffientBalance
		}
		else{
		this.amount-=amount;
		System.out.println("Withdrawn Successfull");
		System.out.println("Amount withdraw was :"+amount);
		return this.amount;
		}*/
		//return amount;
	}
	
	public synchronized void deposit(int amount){
		this.amount+=amount;
		System.out.println("Amount was deposited");
		this.flag++;
		notify();
		
	}
}


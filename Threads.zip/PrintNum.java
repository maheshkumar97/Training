package com.thread;

public class PrintNum {

	public PrintNum() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		Thread t1 = new Thread(new Even());
		Thread t2 = new Thread(new Odd());
		
		t1.start();
		t2.start();
		
	}

}

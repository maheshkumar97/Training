package com.thread;

public class MultiTask implements Runnable{

	public MultiTask(){
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run(){
		for(int i = 0; i<5;i++){
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			};
			System.out.println("Thread: "+Thread.currentThread().getName()+" Iterator: "+i);
		}

	}
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Thread t1 = new Thread(new MultiTask());
		t1.setName("1");
		Thread t2 = new Thread(new MultiTask());
		t2.setName("2");
		Thread t3 = new Thread(new MultiTask());
		t3.setName("3");
		//t3.setPriority(10);
		t1.setPriority(1);
		//t2.setPriority(5);
		
		t1.start();
		t2.start();
		t3.start();

	}

}

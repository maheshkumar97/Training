package com.thread;

public class BankTransaction {

	/*public BankTransaction() {
		// TODO Auto-generated constructor stub
	}*/

	public static void main(String[] args) {
		Customer c = new Customer();
		Thread t1 = new Thread(){
			public void run(){
				c.withdraw(10000);
				System.out.println("Remaining amount is: "+c.amount);
			}
		};
		Thread t2 = new Thread(){
			public void run(){
			c.deposit(5000);
			}
		};
		t1.setName("Mahesh");
		t2.setName("Kumar");
		t1.start();
		t2.start();

	}

}

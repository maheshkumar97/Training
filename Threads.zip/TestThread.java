package com.thread;

public class TestThread implements Runnable{
	
	public TestThread(){
		
	}
	
	/*{
		System.out.println("Run method");
	}*/
	public void run(){
		System.out.println("Run method in: "+Thread.currentThread().getName());
		for(int i =0; i<5;i++){
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(i);
		}
		
	}
	public static void main(String[] args) {
		System.out.println();
		//TestThread t = new TestThread();
		Thread t1 = new Thread(new TestThread());
		Thread t2 = new Thread(new TestThread());
		
		t1.setName("Thread-A");
		t1.start();	
		
		/*try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		t2.setName("Thread-B");
		t2.start();
		
		/*try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		System.out.println("completed");	
	}

}

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;

public class Login {
	Connection con;
	ResultSet resultSet;
	boolean flag;
	public boolean compare(String username, String pass) throws ClassNotFoundException, SQLException{
	try{
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cognizant","root","sql@admin");
		PreparedStatement pst = con.prepareStatement("Select * from login where email = ? and password =?");
		pst.setString(1,username);
		pst.setString(2,pass);
		resultSet = pst.executeQuery();
		boolean b = resultSet.next();
		
		System.out.println(b);
		return b;
		
	} catch (SQLException e) {
		e.printStackTrace();
	}finally{
		con.close();
	}
	return flag;
	}
}

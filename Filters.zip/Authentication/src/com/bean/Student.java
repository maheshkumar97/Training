package com.bean;

//import java.util.Comparator;

public class Student {

		int roolno;
		String stuName;
		int age;

		public int getRoolno() {
			return roolno;
		}

		public void setRoolno(int roolno) {
			this.roolno = roolno;
		}

		public String getStuName() {
			return stuName;
		}

		public void setStuName(String stuName) {
			this.stuName = stuName;
		}

		public int getAge() {
			return age;
		}

		public void setAge(int age) {
			this.age = age;
		}

		
}


package com.iostreams;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TestReader {
	
	/*
	 * FileReader class one of the class used to read data
	 * FileReader a class used to read the data from a file character wise but it return the character in ANSII or UNICODE format
	 * To convert that integer value to character we use the (char)casting explicitly
	 */
	
	public static void main(String[] args) throws IOException {
		try{
		FileReader fr = new FileReader("E:hi.txt");
		int c;
		while((c=fr.read())!=-1){
			System.out.print((char)c);
		}
		fr.close();
	}catch (FileNotFoundException e){
		System.out.println(e);
	}
	}
}
		

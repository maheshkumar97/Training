package com.iostreams;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TesrSerialize {

	
	/*
	 * Serialization Code 
	 */
	static void serialize(Laptop li) throws IOException{
		FileOutputStream fos = new FileOutputStream("E:hi1.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(li);
		fos.close();
		}
	
	
	/*
	 * Deserialization code
	 */
	static Laptop deserialize() throws IOException, ClassNotFoundException{
		FileInputStream fis = new FileInputStream("E:hi1.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Laptop li =  (Laptop)ois.readObject();
		fis.close();
		return li;
	}
		
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Laptop l1 = new Laptop("HP", "ProBook 6470b", 35999, "Intel i5");
		System.out.println(l1);
		serialize(l1);
		
		Laptop l2 = deserialize();
		System.out.println(l2);
	}

}

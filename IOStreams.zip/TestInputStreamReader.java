package com.iostreams;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class TestInputStreamReader {

	public static void main(String[] args) throws IOException {
		
		InputStream fr = new FileInputStream("E:hi.txt");
		InputStreamReader in = new InputStreamReader(fr);
		int c;
		while((c=in.read())!=-1){
			System.out.print((char)c);
		}

	}

}

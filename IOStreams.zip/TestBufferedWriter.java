package com.iostreams;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class TestBufferedWriter {
	/*
	 * BufferedWriter class used to modify the files or add text or date to a file
	 * BufferedWriter class has write() method to write the data onto file
	 * To use a BufferedWriter class, before Create a FileWriter Object to five it into BufferedWriter 
	 */
	public static void main(String[] args) {
		
		try {
			FileWriter fw = new FileWriter("C:/Users/Hp/Documents/hi1.txt",true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write("Mahesh");
			bw.write("kumar");
			bw.close();
			System.out.println("File Created");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}

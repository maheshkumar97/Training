package com.iostreams;

import java.io.Serializable;

public class Laptop implements Serializable {
	
	/*
	 * Creating a serializable class which is used to store its objects in on a harddisk or file or keep in a network
	 * First we must implement Serializable interface
	 * Then we can do Serialization on this Class Objects
	 */
	private String brand;
	private String model;
	private transient double price;  // To make a particulaar value to be restricted to serialization make it a Transient variable
	private String processor;
	
	public Laptop(String brand, String model, double price, String processor) {
		super();
		this.brand = brand;
		this.model = model;
		this.price = price;
		this.processor = processor;
	}

	public Laptop() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "brand= " + brand + "\n model= " + model + "\n price= " + price + "\n processor= " + processor + "";
	}
}

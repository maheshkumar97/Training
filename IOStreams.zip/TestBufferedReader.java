package com.iostreams;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

public class TestBufferedReader {
	
	/*
	 * BufferedReader class used to read the text or date from a file
	 * BufferedReader class has read() method to read the data onto file this will return a integer a character in ANSII or UNICODE
	 * BufferedReader class also has a readLine() method to read data of Single line this will return a String 
	 * To use a BufferedReader class, before Create a FileReader Object to use  
	 */

	public static void main(String[] args) throws FileNotFoundException {
		FileReader fr = new FileReader("E:hi.txt");
		//InputStream fr = new FileInputStream("E:hi.txt");
		BufferedReader br = new BufferedReader(fr);
		String line;
		//int line;
		try {
			while((line=br.readLine())!=null){
				System.out.println(line);
			}
			fr.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

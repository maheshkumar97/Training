package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.Class;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	public boolean compare(String email, String pass) throws SQLException, ClassNotFoundException {
		
		ResultSet resultSet;
		Connection con;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cognizant","root","sql@admin");
		PreparedStatement pst = con.prepareStatement("Select * from login where email = ? and password =?");
		pst.setString(1,email);
		pst.setString(2,pass);
		resultSet = pst.executeQuery();
		boolean b = resultSet.next();
		
		System.out.println(b);
		return resultSet.next();

	}
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String email = request.getParameter("name");
		String pass = request.getParameter("pass");
		
		try {
			Login l = new Login();
			boolean b = l.compare(email,pass);
			out.println(b);
			if(b){//l.compare(str1, str2)
				RequestDispatcher rd = request.getRequestDispatcher("/Welcome");
				rd.forward(request, response);			
			}
			
			else{
				RequestDispatcher rd = request.getRequestDispatcher("index.html");
				rd.include(request, response);
				out.print("Enter the Correct password!\n"
						+ "you enterd data is \n"
						+ "Name : " +request.getParameter("name")+"\n"
						+ "Password : " +request.getParameter("pass")+" ");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		//doGet(request, response);
	}

/*	private String getParameter(String string) {
		// TODO Auto-generated method stub
		return null;
	}*/

}
